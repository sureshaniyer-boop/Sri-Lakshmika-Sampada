# Sri Lakshmika Sampada — Boutique Website

A premium, responsive, static website prototype designed for a Malaysian Aari blouse boutique.

## Preview

Open `index.html` in a desktop browser or deploy the entire folder to a static web host. No build commands or paid services are needed to preview the site.

## Before sharing with customers

1. Open `products.js` and set `whatsappNumber` to your business WhatsApp number **with country code, digits only** (e.g., `60123456789`). The sample number shown here is a formatting example; do not use it unless it is yours.
2. Set `instagramUrl` and `tiktokUrl` to your business profile links.
3. Replace ALL sample products with actual products. The existing blouse graphics are **illustrative mockups only**, not actual product photographs or inventory.
4. Save real product photos under `images/`, then update the `image` property in `products.js` and adjust name, colour, category, material, price and stock wording.
5. Replace the initial suggested category ranges with the actual prices your wife sets.
6. Review the store's return policy, delivery terms, privacy notice, and payment workflow before accepting payments. None of these is provided by this demo.
7. Publish to your domain using GitHub Pages, Netlify, Cloudflare Pages or another static host. Hosting and domain are **not** configured in this package.

## Product data example

```js
{
  id: 'EL-001',
  name: 'Rose Gold Peacock',
  category: 'elegance', // elegance | premium | bridal | ready
  image: 'images/EL-001.jpg',
  color: 'Maroon',
  material: 'Raw silk with hand Aari work',
  price: 89, // Malaysian Ringgit; use null to show "Price on enquiry"
  status: 'Ready stock'
}
```

## What is working

- Responsive storefront with original supplied brand logo
- Four collection landing cards (Elegance, Premium Elegance, Royal Bridal Collection, Ready-to-Wear Elegance)
- Live catalogue search, filters, product detail window
- Client enquiry shortlist (per browser session)
- WhatsApp enquiry with product codes when business number is configured
- Copyable enquiry fallback when no WhatsApp number is supplied
- Basic accessibility and navigation support

## What is NOT included

- Real inventory, product photographs or verified prices
- Public website hosting or domain registration
- Customer accounts, payment gateway, order processing, server database or inventory synchronization
- Automated fulfilment or shipping integration
- Privacy, return or delivery policies

The store owner should upload real inventory and configure contact channels before publication.
