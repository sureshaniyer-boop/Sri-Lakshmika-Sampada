/* Original back view -> new front view -> back view.
   Each fully displayed image holds for 5000ms; wipes last 850ms.
   Repeats indefinitely while page is visible. */
(function () {
  'use strict';
  const gallery = document.querySelector('.hero-wipe-gallery');
  if (!gallery) return;
  const back = gallery.querySelector('.hero-slide-back');
  const front = gallery.querySelector('.hero-slide-front');
  if (!back || !front) return;
  const HOLD_MS = 5000;
  const WIPE_MS = 850;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  let active = back;
  let timer = null;
  let running = false;
  let finished = null;
  function clearAnimation() {
    if (timer !== null) { window.clearTimeout(timer); timer = null; }
    if (finished) { finished.cancel(); finished = null; }
    for (const slide of [back, front]) {
      slide.classList.remove('is-incoming');
      slide.style.removeProperty('clip-path');
      slide.style.removeProperty('z-index');
    }
  }
  function reset() {
    clearAnimation();
    active = back;
    back.classList.add('is-visible');
    front.classList.remove('is-visible');
    back.setAttribute('aria-hidden', 'false');
    front.setAttribute('aria-hidden', 'true');
    if (!document.hidden && !reduceMotion.matches) schedule();
  }
  function schedule() {
    timer = window.setTimeout(transition, HOLD_MS);
  }
  function transition() {
    timer = null;
    if (document.hidden || reduceMotion.matches) return;
    const incoming = active === back ? front : back;
    incoming.classList.add('is-incoming', 'is-visible');
    incoming.style.zIndex = '2';
    incoming.setAttribute('aria-hidden', 'false');
    incoming.style.clipPath = 'inset(0 0 0 100%)';
    // The left clip edge travels from 100% to 0%: visual reveal right -> left.
    const animation = incoming.animate([
      { clipPath: 'inset(0 0 0 100%)' },
      { clipPath: 'inset(0 0 0 0%)' }
    ], { duration: WIPE_MS, easing: 'ease-in-out', fill: 'forwards' });
    finished = animation;
    animation.onfinish = () => {
      if (animation !== finished) return;
      const previous = active;
      active = incoming;
      incoming.classList.remove('is-incoming');
      incoming.style.removeProperty('clip-path');
      incoming.style.removeProperty('z-index');
      previous.classList.remove('is-visible');
      previous.setAttribute('aria-hidden', 'true');
      animation.cancel();
      finished = null;
      schedule();
    };
  }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) clearAnimation();
    else reset();
  });
  if (reduceMotion.addEventListener) reduceMotion.addEventListener('change', reset);
  reset();
})();
